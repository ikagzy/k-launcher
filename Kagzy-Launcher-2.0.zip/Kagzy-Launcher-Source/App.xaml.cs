using Application = System.Windows.Application;
using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using KLauncher.Services;

namespace KLauncher;

public partial class App : Application
{
    private const string SingleInstanceMutexName = @"Local\KLauncher.SingleInstance";
    private Mutex? _singleInstanceMutex;
    private bool _ownsSingleInstanceMutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += App_DispatcherUnhandledException;
        try
        {
            if (AppInstallationBootstrapper.InstallAndRelaunchIfNeeded(e.Args))
            {
                Shutdown();
                return;
            }

            LauncherStorage.Initialize();

            if (!TryAcquireSingleInstance())
            {
                MessageBox.Show(
                    "K-Launcher zaten açık. Lütfen önce açık olan uygulamayı kapatın.",
                    "K-Launcher",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                Shutdown();
                return;
            }

            var window = new MainWindow();
            MainWindow = window;
            window.Show();
            window.Activate();
            window.Focus();
        }
        catch (Exception ex)
        {
            ShowFatal(ex);
            Shutdown(-1);
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        if (_ownsSingleInstanceMutex)
            _singleInstanceMutex?.ReleaseMutex();

        _singleInstanceMutex?.Dispose();
        base.OnExit(e);
    }

    private bool TryAcquireSingleInstance()
    {
        _singleInstanceMutex = new Mutex(initiallyOwned: false, SingleInstanceMutexName);
        try
        {
            _ownsSingleInstanceMutex = _singleInstanceMutex.WaitOne(0);
        }
        catch (AbandonedMutexException)
        {
            _ownsSingleInstanceMutex = true;
        }

        return _ownsSingleInstanceMutex;
    }

    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        ShowFatal(e.Exception);
        e.Handled = true;
        Shutdown(-1);
    }

    private static void ShowFatal(Exception ex)
    {
        MessageBox.Show(
            $"K-Launcher başlatılamadı.\n\n{ex}",
            "K-Launcher",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }
}
