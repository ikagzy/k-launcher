using System.IO;

namespace KLauncher.Services;

/// <summary>
/// Keeps mutable launcher data beside the installed executable so the app does
/// not need to rebuild it from the system on every start. A legacy fallback is
/// retained for protected install locations.
/// </summary>
public static class LauncherStorage
{
    private static readonly object Sync = new();
    private static readonly string LegacyDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "K-Launcher");

    private static readonly string[] MigratedFiles =
    [
        "custom-apps.json",
        "hidden-apps.json",
        "quick-links.json",
        "quick-links-removed.json",
        "scanner.log",
        "app-cache.json"
    ];

    private static string? _dataDirectory;

    public static string DataDirectory
    {
        get
        {
            lock (Sync)
                return _dataDirectory ??= ResolveDataDirectory();
        }
    }

    public static string GetFilePath(string fileName) =>
        Path.Combine(DataDirectory, fileName);

    public static void Initialize() => _ = DataDirectory;

    private static string ResolveDataDirectory()
    {
        var preferredDirectory = Path.Combine(AppContext.BaseDirectory, "Data");
        try
        {
            Directory.CreateDirectory(preferredDirectory);
            MigrateLegacyFiles(preferredDirectory);
            return preferredDirectory;
        }
        catch (UnauthorizedAccessException)
        {
            Directory.CreateDirectory(LegacyDirectory);
            return LegacyDirectory;
        }
        catch (IOException)
        {
            Directory.CreateDirectory(LegacyDirectory);
            return LegacyDirectory;
        }
    }

    private static void MigrateLegacyFiles(string destinationDirectory)
    {
        if (!Directory.Exists(LegacyDirectory) ||
            Path.GetFullPath(LegacyDirectory).Equals(
                Path.GetFullPath(destinationDirectory),
                StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        foreach (var fileName in MigratedFiles)
        {
            var sourcePath = Path.Combine(LegacyDirectory, fileName);
            var destinationPath = Path.Combine(destinationDirectory, fileName);
            if (!File.Exists(sourcePath) || File.Exists(destinationPath))
                continue;

            try
            {
                File.Copy(sourcePath, destinationPath);
            }
            catch
            {
                // One failed optional migration must not prevent startup.
            }
        }
    }
}
