# K-Launcher

A lightweight desktop launcher for Windows that brings your games, game stores and apps together in one place.

**Current version:** 4.1 Beta

## What's New in 4.0

- **Showcase view** (formerly "Overview"): right-click an app to open its games, links and actions as large cards you scroll sideways with the mouse wheel, drag or touchpad.
- **Driver tools:** a new "Driver tools" category in Batch Install with 13 apps for GPU and system driver maintenance.
- **Epic Games detection:** every game installed with the new Epic Games client is detected, and newly installed games appear automatically.
- **Particle setting:** background particles can be turned on or off in Settings.
- **Window fade setting:** turns the fade-out when K-Launcher is minimized or in the background on or off.
- **Release notes button:** the top bar has a button that opens the release notes.
- **Error log:** the "Open error log" button in Settings opens the log file. Your user name is not written to it.
- Dialogs no longer show up separately in Alt+Tab, and starting K-Launcher while it is already running brings the open window to the front.

## Features

- **Automatic detection:** Finds supported launchers, games and apps from common install locations, Start Menu shortcuts and Windows app registration data. Apps from the batch-install list are added automatically however they were installed, including portable ones.
- **Batch install:** Pick from 144 apps and install them in one go through Windows Package Manager (winget). Includes presets ("Gaming PC", "Software development", "School"), installed/update marks, update all, bulk uninstall, a single administrator approval for the whole batch and retrying failed items. Steam and Epic games can be installed by name.
- **Interface modes:** Classic card view, list view with app and content panels, and the Showcase view.
- **Themes:** 7 built-in color themes; particles, menus and buttons follow the selected theme.
- **Animation speed:** Fast, Normal, Slow or Off.
- **Low memory use:** Non-essential data is kept on disk and loaded when needed. While minimized or in the tray, K-Launcher uses Windows efficiency mode and low memory priority.
- **Multilingual interface:** Interface, settings, dialogs and automatic install messages are translated, with right-to-left layout for languages that need it. Machine-translated entries should be reviewed by fluent speakers.
- **Touch screen code generator:** Generates Arduino touch code for displays on ESP32, ESP32-S3, ESP32-C3, ESP8266, Raspberry Pi Pico and Arduino boards (XPT2046, FT6206/FT6236, GT911, CST816S), with an automatic touch chip finder that reads the result over USB serial.
- **Single instance, system tray and Windows startup** options.

## Downloads

Download the compiled Windows executable from itch.io:

- [K-Launcher on itch.io](https://itzkagzy.itch.io/k-launcher)

The executable is a self-contained Windows x64 build with everything built in. On first launch it copies itself to `%LOCALAPPDATA%\Programs\K-Launcher`, creates a desktop shortcut once, removes the downloaded copy and starts the installed one. Settings are stored next to the installed executable in a `Data` folder.

K-Launcher does not bundle any game store; it opens and installs games through the official Steam, Epic Games and other launchers installed on your PC.

## Build from Source

### Requirements

- Windows 10 or 11
- .NET 10 SDK

### Build

```powershell
dotnet restore .\KLauncher.csproj
dotnet build .\KLauncher.csproj -c Release
```

### Publish a self-contained Windows x64 executable

```powershell
dotnet publish .\KLauncher.csproj `
  -c Release `
  -r win-x64 `
  --self-contained true `
  -p:PublishSingleFile=true `
  -p:IncludeNativeLibrariesForSelfExtract=true `
  -p:IncludeAllContentForSelfExtract=true `
  -p:DebugType=None `
  -o .\dist
```

The published executable will be at `dist\KLauncher.exe`.

## Project Structure

- `Services/` — scanning, storage, winget batch install, store automation, localization, settings (particles, window fade, motion), error log, touch code generator
- `Services/Localization/` — translation catalogs
- `Models/`, `ViewModels/` — app data and the main view model
- `Themes/` — shared design tokens (`KTheme.xaml`), icons and dialog chrome
- `Assets/` — logos, theme icons and bundled images
- `Tools/` — helper scripts for building and measuring memory use

## Built With

- **Language/UI:** C# and WPF
- **Framework:** .NET 10

## License

This project is licensed under the **GNU General Public License v3.0 (GPL-3.0)**.
Developed by **itzkagzy**. Free to use, modify, and distribute as long as all derivative works remain open-source under the same license. See [LICENSE](./LICENSE) for the full license text.
