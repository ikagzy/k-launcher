using Application = System.Windows.Application;
using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using KLauncher.Services;

namespace KLauncher;

public partial class App : Application
{
    private const string SingleInstanceMutexName = @"Local\KLauncher.SingleInstance";
    private Mutex? _singleInstanceMutex;
    private bool _ownsSingleInstanceMutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += App_DispatcherUnhandledException;
        // Elevated helper for batch installs: no window, no install check, no
        // single-instance lock (the normal launcher is already running).
        if (e.Args.Length == 2 && e.Args[0] == WingetBatchHost.HelperArgument)
        {
            RunWingetBatchHelper(e.Args[1]);
            return;
        }

        try
        {
            // First start after a portable install: remove the portable EXE;
            // the desktop shortcut created on startup replaces it.
            var arguments = AppInstallationBootstrapper.RemovePortableCopy(e.Args);

            if (AppInstallationBootstrapper.InstallAndRelaunchIfNeeded(arguments))
            {
                Shutdown();
                return;
            }

            LauncherStorage.Initialize();
            MotionSettings.ApplyThemeTokens();

            if (!TryAcquireSingleInstance())
            {
                MessageBox.Show(
                    "K-Launcher zaten açık. Lütfen önce açık olan uygulamayı kapatın.",
                    "K-Launcher",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                Shutdown();
                return;
            }

            var window = new MainWindow();
            MainWindow = window;
            window.Show();
            window.Activate();
            window.Focus();
        }
        catch (Exception ex)
        {
            ShowFatal(ex);
            Shutdown(-1);
        }
    }

    private async void RunWingetBatchHelper(string folder)
    {
        try
        {
            await WingetBatchHost.RunHelperAsync(folder);
        }
        catch
        {
            // The launcher reports unfinished items itself.
        }
        finally
        {
            Shutdown();
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        if (_ownsSingleInstanceMutex)
            _singleInstanceMutex?.ReleaseMutex();

        _singleInstanceMutex?.Dispose();
        base.OnExit(e);
    }

    private bool TryAcquireSingleInstance()
    {
        _singleInstanceMutex = new Mutex(initiallyOwned: false, SingleInstanceMutexName);
        try
        {
            _ownsSingleInstanceMutex = _singleInstanceMutex.WaitOne(0);
        }
        catch (AbandonedMutexException)
        {
            _ownsSingleInstanceMutex = true;
        }

        return _ownsSingleInstanceMutex;
    }

    private void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        ShowFatal(e.Exception);
        e.Handled = true;
        Shutdown(-1);
    }

    private static void ShowFatal(Exception ex)
    {
        MessageBox.Show(
            $"K-Launcher başlatılamadı.\n\n{ex}",
            "K-Launcher",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
    }
}
